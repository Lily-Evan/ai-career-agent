from pathlib import Path

def load_template(name: str) -> str:
    path = Path("templates") / name
    return path.read_text(encoding="utf-8")
