def search_and_apply_jobs():
    # TODO: Implement job search + quick-apply where allowed; otherwise queue for review
    print("[jobs] search relevant roles and apply/queue")
