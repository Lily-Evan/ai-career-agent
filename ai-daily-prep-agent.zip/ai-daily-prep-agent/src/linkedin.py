def review_invitations():
    # TODO: Implement LinkedIn invitations fetch + heuristics
    print("[linkedin] review invitations and propose accept/decline")

def network_and_messages():
    # TODO: Implement connection strategy + follow-up messages
    print("[linkedin] connect with target profiles and send follow-ups")

def create_linkedin_post():
    # TODO: Render from templates/linkedin_post.md and post (or queue) on LinkedIn
    print("[linkedin] create/schedule a LinkedIn post from template")
