from src.utils import logger
from src.email import process_email_summaries
from src.linkedin import review_invitations, network_and_messages, create_linkedin_post
from src.jobs import search_and_apply_jobs

def run_daily():
    logger.info("Starting daily workflow")
    process_email_summaries(daily=True)
    review_invitations()
    search_and_apply_jobs()
    create_linkedin_post()
    network_and_messages()
    logger.info("Daily workflow complete")

def run_hourly():
    logger.info("Starting hourly workflow")
    process_email_summaries(daily=False)
    review_invitations()
    logger.info("Hourly workflow complete")
