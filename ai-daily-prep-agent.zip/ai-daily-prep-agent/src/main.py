import argparse
from src.orchestrator import run_daily, run_hourly

def parse_args():
    p = argparse.ArgumentParser(description="AI Daily Prep Agent")
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--daily", action="store_true", help="Run full daily workflow")
    g.add_argument("--hourly", action="store_true", help="Run lightweight hourly workflow")
    return p.parse_args()

def main():
    args = parse_args()
    if args.daily:
        run_daily()
    elif args.hourly:
        run_hourly()

if __name__ == "__main__":
    main()
