import os, sys, yaml, pathlib
from loguru import logger as _logger

CONFIG_PATH = pathlib.Path("config.yaml")
STATE_DIR_DEFAULT = pathlib.Path(os.path.expanduser("~/.ai_daily_prep"))

def load_config():
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    return {}

def state_dir():
    cfg = load_config()
    p = pathlib.Path(cfg.get("storage", {}).get("state_dir", STATE_DIR_DEFAULT))
    p.mkdir(parents=True, exist_ok=True)
    return p

logger = _logger
_logger.remove()
_logger.add(sys.stderr, level="INFO")
